package com.android.demo.templeease.utils

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

/** Checks real-time network connectivity using ConnectivityManager.
 *  Requires ACCESS_NETWORK_STATE permission (already in manifest). */
fun isNetworkAvailable(context: Context): Boolean {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        ?: return false
    val network = cm.activeNetwork ?: return false
    val caps   = cm.getNetworkCapabilities(network) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
           caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
}
