package com.android.demo.templeease.data.model

data class SOSAlert(

    val location: String = "",

    val message: String = ""
)