package com.android.demo.templeease.ui.components

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.People
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.android.demo.templeease.data.model.CrowdStatus
import com.android.demo.templeease.ui.theme.CardSurface
import com.android.demo.templeease.ui.theme.CrowdHigh
import com.android.demo.templeease.ui.theme.CrowdHighContainer
import com.android.demo.templeease.ui.theme.CrowdLow
import com.android.demo.templeease.ui.theme.CrowdLowContainer
import com.android.demo.templeease.ui.theme.CrowdMedium
import com.android.demo.templeease.ui.theme.CrowdMediumContainer
import com.android.demo.templeease.ui.theme.Dimens
import com.android.demo.templeease.ui.theme.TextSecondary

/**
 * Premium crowd status card used in HomeScreen and AnalyticsScreen.
 * Shows gate name, crowd level chip, wait time, and a colored left accent border.
 */
@Composable
fun CrowdCard(
    crowd: CrowdStatus,
    modifier: Modifier = Modifier
) {
    val (accentColor, bgColor) = when (crowd.crowdLevel.uppercase()) {
        "HIGH"   -> Pair(CrowdHigh,   CrowdHighContainer)
        "MEDIUM" -> Pair(CrowdMedium, CrowdMediumContainer)
        else     -> Pair(CrowdLow,    CrowdLowContainer)
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = accentColor.copy(alpha = 0.25f),
                shape = RoundedCornerShape(Dimens.RadiusLg)
            ),
        shape = RoundedCornerShape(Dimens.RadiusLg),
        colors = CardDefaults.cardColors(containerColor = CardSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = Dimens.ElevationMid)
    ) {
        Row(
            modifier = Modifier.padding(Dimens.SpacingMd),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Colored left accent strip
            androidx.compose.foundation.layout.Box(
                modifier = Modifier
                    .width(4.dp)
                    .height(52.dp)
                    .then(
                        Modifier
                            .padding(end = 0.dp)
                    )
            ) {
                androidx.compose.foundation.Canvas(modifier = Modifier.matchParentSize()) {
                    drawRoundRect(
                        color = accentColor,
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f)
                    )
                }
            }

            Spacer(modifier = Modifier.width(Dimens.SpacingMd))

            // Icon
            Icon(
                imageVector = Icons.Default.People,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(Dimens.IconLg)
            )

            Spacer(modifier = Modifier.width(Dimens.SpacingMd))

            // Info column
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = crowd.gateName,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Wait: ${crowd.waitingTime}",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }

            // Status chip
            CrowdStatusChip(crowdLevel = crowd.crowdLevel)
        }
    }
}
