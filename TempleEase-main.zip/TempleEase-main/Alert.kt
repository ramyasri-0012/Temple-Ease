package com.android.demo.templeease.data.model


data class Alert(

    val title: String = "",

    val message: String = ""
)