package com.android.demo.templeease.ui.navigation


object Routes {

    const val SPLASH = "splash"

    const val ROLE_SELECTION = "role_selection"

    const val LOGIN = "login"

    const val REGISTER = "register"

    const val USER_DASHBOARD = "user_dashboard"

    const val ADMIN_DASHBOARD = "admin_dashboard"
    const val ANALYTICS = "analytics"
    const val SOS_MONITOR = "sos_monitor"
}