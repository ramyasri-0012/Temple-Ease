package com.android.demo.templeease.data.model

/** Severity level used for coloring notification cards */
enum class NotificationSeverity { LOW, MEDIUM, HIGH }

/**
 * Represents an in-app notification for the pilgrim.
 * Severity drives color coding: LOW=green, MEDIUM=amber, HIGH=red.
 */
data class AppNotification(
    val id: String,
    val title: String,
    val message: String,
    val severity: NotificationSeverity,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val icon: String = "bell" // "crowd" | "parking" | "emergency" | "route" | "bell"
)
