package com.android.demo.templeease.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.android.demo.templeease.ui.theme.CrowdHigh
import com.android.demo.templeease.ui.theme.CrowdHighContainer
import com.android.demo.templeease.ui.theme.CrowdLow
import com.android.demo.templeease.ui.theme.CrowdLowContainer
import com.android.demo.templeease.ui.theme.CrowdMedium
import com.android.demo.templeease.ui.theme.CrowdMediumContainer

/**
 * Colored status chip for crowd levels (LOW / MEDIUM / HIGH).
 * Shows a colored dot + label inside a rounded pill background.
 */
@Composable
fun CrowdStatusChip(crowdLevel: String) {
    val (dotColor, bgColor, label) = when (crowdLevel.uppercase()) {
        "HIGH"   -> Triple(CrowdHigh,   CrowdHighContainer,   "HIGH")
        "MEDIUM" -> Triple(CrowdMedium, CrowdMediumContainer, "MEDIUM")
        else     -> Triple(CrowdLow,    CrowdLowContainer,    "LOW")
    }

    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50.dp))
            .background(bgColor)
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(dotColor)
        )
        Text(
            text = label,
            color = dotColor,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            letterSpacing = 0.8.sp
        )
    }
}
