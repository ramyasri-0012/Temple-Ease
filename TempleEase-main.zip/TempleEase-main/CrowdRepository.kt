package com.android.demo.templeease.data.repository

import com.android.demo.templeease.data.model.CrowdStatus
import com.google.firebase.firestore.FirebaseFirestore

class CrowdRepository {

    private val firestore = FirebaseFirestore.getInstance()

    fun updateCrowdStatus(

        gateName: String,
        crowdLevel: String,

        onSuccess: () -> Unit,

        onFailure: (String) -> Unit

    ) {

        val latitude = when(gateName) {

            "Gate A" -> 22.2394
            "Gate B" -> 22.2400
            else -> 22.2410
        }

        val longitude = when(gateName) {

            "Gate A" -> 68.9678
            "Gate B" -> 68.9685
            else -> 68.9690
        }

        val waitingTime = when(crowdLevel) {

            "HIGH" -> "35 Minutes"

            "MEDIUM" -> "20 Minutes"

            else -> "5 Minutes"
        }

        val crowd = CrowdStatus(

            gateName = gateName,

            crowdLevel = crowdLevel,

            latitude = latitude,

            longitude = longitude,

            waitingTime = waitingTime
        )

        firestore.collection("crowd_status")
            .document(gateName)
            .set(crowd)

            .addOnSuccessListener {

                onSuccess()
            }

            .addOnFailureListener {

                onFailure(
                    it.message ?: "Firestore Error"
                )
            }
    }
    fun getCrowdStatus(

        onDataChanged: (List<CrowdStatus>) -> Unit

    ) {

        firestore.collection("crowd_status")

            .addSnapshotListener { value, _ ->

                val crowdList = mutableListOf<CrowdStatus>()

                value?.documents?.forEach {

                    val crowd =
                        it.toObject(CrowdStatus::class.java)

                    if(crowd != null) {

                        crowdList.add(crowd)
                    }
                }

                onDataChanged(crowdList)
            }
    }
    fun sendAlert(

        title: String,
        message: String,

        onSuccess: () -> Unit,

        onFailure: (String) -> Unit

    ) {

        val alert = hashMapOf(

            "title" to title,

            "message" to message
        )

        firestore.collection("alerts")

            .add(alert)

            .addOnSuccessListener {

                onSuccess()
            }

            .addOnFailureListener {

                onFailure(
                    it.message ?: "Alert Failed"
                )
            }
    }
    fun sendSOS(

        location: String,
        message: String,

        onSuccess: () -> Unit,

        onFailure: (String) -> Unit

    ) {

        val sos = hashMapOf(

            "location" to location,

            "message" to message
        )

        firestore.collection("sos_alerts")

            .add(sos)

            .addOnSuccessListener {

                onSuccess()
            }

            .addOnFailureListener {

                onFailure(
                    it.message ?: "SOS Failed"
                )
            }
    }
    fun updateParking(

        parkingName: String,

        availableSlots: Int,

        onSuccess: () -> Unit,

        onFailure: (String) -> Unit

    ) {

        val parking = hashMapOf(

            "parkingName" to parkingName,

            "availableSlots" to availableSlots
        )

        firestore.collection("parking")

            .document(parkingName)

            .set(parking)

            .addOnSuccessListener {

                onSuccess()
            }

            .addOnFailureListener {

                onFailure(
                    it.message ?: "Parking Update Failed"
                )
            }
    }
}