package com.android.demo.templeease.data.model

data class User(

    val uid: String = "",

    val name: String = "",

    val email: String = "",

    val role: String = ""
)