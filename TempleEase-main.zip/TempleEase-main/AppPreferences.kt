package com.android.demo.templeease.utils

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore

/** DataStore singleton — one instance per process */
val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "temple_ease_prefs")

object AppPreferencesKeys {
    val IS_DARK_THEME  = booleanPreferencesKey("is_dark_theme")
    val LANGUAGE_CODE  = stringPreferencesKey("language_code")
    val NOTIF_ENABLED  = booleanPreferencesKey("notif_enabled")
}
