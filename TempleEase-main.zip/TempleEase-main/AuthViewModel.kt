package com.android.demo.templeease.viewmodel

import androidx.lifecycle.ViewModel
import com.android.demo.templeease.data.repository.AuthRepository

class AuthViewModel : ViewModel() {

    private val repository = AuthRepository()

    fun registerUser(

        name: String,
        email: String,
        password: String,
        role: String,

        onSuccess: () -> Unit,

        onFailure: (String) -> Unit

    ) {

        repository.registerUser(
            name,
            email,
            password,
            role,
            onSuccess,
            onFailure
        )
    }

    fun loginUser(

        email: String,
        password: String,

        onSuccess: (String) -> Unit,

        onFailure: (String) -> Unit

    ) {

        repository.loginUser(
            email,
            password,
            onSuccess,
            onFailure
        )
    }
}