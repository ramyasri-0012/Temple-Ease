package com.android.demo.templeease.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TempleEaseDarkColorScheme = darkColorScheme(
    primary = Saffron,
    onPrimary = TextOnSaffron,
    primaryContainer = SaffronContainer,
    onPrimaryContainer = OnSaffronContainer,

    secondary = SaffronLight,
    onSecondary = TextOnSaffron,
    secondaryContainer = Color(0xFF3A1800),
    onSecondaryContainer = Color(0xFFFFDDB8),

    tertiary = GoldenAccent,
    onTertiary = Color(0xFF1A1200),
    tertiaryContainer = Color(0xFF2E2200),
    onTertiaryContainer = Color(0xFFFFEA80),

    background = DeepNight,
    onBackground = TextPrimary,

    surface = NightSurface,
    onSurface = TextPrimary,
    surfaceVariant = CardSurface,
    onSurfaceVariant = TextSecondary,

    error = CrowdHigh,
    onError = Color.White,
    errorContainer = CrowdHighContainer,
    onErrorContainer = Color(0xFFFFB4AB),

    outline = OutlineMedium,
    outlineVariant = OutlineSubtle,

    surfaceTint = Saffron,
    inverseSurface = SoftWhite,
    inverseOnSurface = Color(0xFF1A1410),
)

@Composable
fun TempleEaseTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = TempleEaseDarkColorScheme,
        typography = TempleEaseTypography,
        content = content
    )
}