package com.android.demo.templeease.ui.screens.user

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.android.demo.templeease.ui.components.SectionHeader
import com.android.demo.templeease.ui.components.TempleButton
import com.android.demo.templeease.ui.components.TempleOutlineButton
import com.android.demo.templeease.ui.components.TempleTextField
import com.android.demo.templeease.ui.navigation.Routes
import com.android.demo.templeease.ui.theme.CrowdHigh
import com.android.demo.templeease.ui.theme.CrowdHighContainer
import com.android.demo.templeease.ui.theme.DeepNight
import com.android.demo.templeease.ui.theme.Dimens
import com.android.demo.templeease.ui.theme.OutlineSubtle
import com.android.demo.templeease.ui.theme.Saffron
import com.android.demo.templeease.ui.theme.SaffronContainer
import com.android.demo.templeease.ui.theme.TextSecondary
import com.android.demo.templeease.viewmodel.CrowdViewModel
import com.google.firebase.auth.FirebaseAuth

/**
 * User profile screen.
 * - Top avatar with user initials from Firebase
 * - SOS emergency form (location + message) in a colored card section
 * - Logout outlined button at the bottom
 * - verticalScroll + imePadding for keyboard-aware behavior
 */
@Composable
fun ProfileScreen(navController: NavController) {
    val context = LocalContext.current
    val viewModel: CrowdViewModel = viewModel()
    val scrollState = rememberScrollState()
    val currentUser = FirebaseAuth.getInstance().currentUser

    var location by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var isSosLoading by remember { mutableStateOf(false) }

    val userEmail = currentUser?.email ?: "pilgrim@temple.in"
    val initials = userEmail.take(2).uppercase()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepNight)
            .verticalScroll(scrollState)  // ← Keyboard-aware scroll
            .imePadding()                 // ← Push above keyboard
            .padding(horizontal = Dimens.ScreenPadding)
            .padding(vertical = Dimens.SpacingXl),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(Dimens.SpacingXl))

        // ── Avatar ────────────────────────────────────────────────────────────
        Box(
            modifier = Modifier
                .size(Dimens.AvatarLg)
                .clip(CircleShape)
                .background(SaffronContainer),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = initials,
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.ExtraBold
                ),
                color = Saffron
            )
        }

        Spacer(modifier = Modifier.height(Dimens.SpacingMd))

        Text(
            text = "My Profile",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = userEmail,
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary
        )

        Spacer(modifier = Modifier.height(Dimens.SpacingXxl))

        HorizontalDivider(color = OutlineSubtle)

        Spacer(modifier = Modifier.height(Dimens.SpacingXl))

        // ── SOS Section header ────────────────────────────────────────────────
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(Dimens.SpacingXs)
        ) {
            Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = null,
                tint = CrowdHigh,
                modifier = Modifier.size(Dimens.IconMd)
            )
            SectionHeader(title = "Emergency SOS")
        }

        Spacer(modifier = Modifier.height(Dimens.SpacingMd))

        // ── Location field ────────────────────────────────────────────────────
        TempleTextField(
            value = location,
            onValueChange = { location = it },
            label = "Your current location",
            leadingIcon = Icons.Default.MyLocation,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(Dimens.SpacingMd))

        // ── Message field ─────────────────────────────────────────────────────
        TempleTextField(
            value = message,
            onValueChange = { message = it },
            label = "Emergency message",
            singleLine = false,
            minLines = 3,
            maxLines = 5,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(Dimens.SpacingLg))

        // ── SOS button ────────────────────────────────────────────────────────
        TempleButton(
            text = "🚨  Send Emergency SOS",
            isLoading = isSosLoading,
            leadingIcon = null,
            onClick = {
                isSosLoading = true
                viewModel.sendSOS(
                    location, message,
                    onSuccess = {
                        isSosLoading = false
                        Toast.makeText(context, "SOS Sent ✓", Toast.LENGTH_SHORT).show()
                        location = ""; message = ""
                    },
                    onFailure = {
                        isSosLoading = false
                        Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
                    }
                )
            }
        )

        Spacer(modifier = Modifier.height(Dimens.SpacingXxl))

        HorizontalDivider(color = OutlineSubtle)

        Spacer(modifier = Modifier.height(Dimens.SpacingXl))

        // ── Logout ────────────────────────────────────────────────────────────
        TempleOutlineButton(
            text = "Sign Out",
            onClick = {
                FirebaseAuth.getInstance().signOut()
                navController.navigate(Routes.LOGIN) {
                    popUpTo(Routes.USER_DASHBOARD) { inclusive = true }
                }
            }
        )

        Spacer(modifier = Modifier.height(Dimens.SpacingXxl))
    }
}