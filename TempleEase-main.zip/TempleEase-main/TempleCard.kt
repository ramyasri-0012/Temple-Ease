package com.android.demo.templeease.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.android.demo.templeease.ui.theme.CardSurface
import com.android.demo.templeease.ui.theme.Dimens
import com.android.demo.templeease.ui.theme.OutlineSubtle

@Composable
fun TempleCard(
    modifier: Modifier = Modifier,
    containerColor: Color = CardSurface,
    elevation: Dp = Dimens.ElevationMid,
    borderColor: Color? = null,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {


    val shape = RoundedCornerShape(Dimens.CardRadius)

    val border = BorderStroke(
        width = 1.dp,
        color = borderColor ?: OutlineSubtle
    )

    if (onClick != null) {

        Card(
            onClick = onClick,
            modifier = modifier,
            shape = shape,
            colors = CardDefaults.cardColors(
                containerColor = containerColor
            ),
            elevation = CardDefaults.cardElevation(
                defaultElevation = elevation
            ),
            border = border
        ) {

            Column(
                modifier = Modifier.padding(Dimens.CardPadding)
            ) {
                content()
            }
        }

    } else {

        Card(
            modifier = modifier,
            shape = shape,
            colors = CardDefaults.cardColors(
                containerColor = containerColor
            ),
            elevation = CardDefaults.cardElevation(
                defaultElevation = elevation
            ),
            border = border
        ) {

            Column(
                modifier = Modifier.padding(Dimens.CardPadding)
            ) {
                content()
            }
        }
    }

}
