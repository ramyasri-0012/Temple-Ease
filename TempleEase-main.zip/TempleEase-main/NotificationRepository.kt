package com.android.demo.templeease.data.repository

import com.android.demo.templeease.data.model.AppNotification
import com.android.demo.templeease.data.model.NotificationSeverity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/** In-memory notification repository with realistic demo data.
 *  Replace Firebase listener here when backend is ready. */
class NotificationRepository {

    private val _notifications = MutableStateFlow(demoNotifications())
    val notifications: StateFlow<List<AppNotification>> = _notifications.asStateFlow()

    fun markAsRead(id: String) {
        _notifications.update { list ->
            list.map { if (it.id == id) it.copy(isRead = true) else it }
        }
    }

    fun markAllRead() {
        _notifications.update { list -> list.map { it.copy(isRead = true) } }
    }

    private fun demoNotifications() = listOf(
        AppNotification(
            id = "1",
            title = "Gate A Becoming Crowded",
            message = "Crowd level at Gate A just changed to HIGH. Consider using Gate B.",
            severity = NotificationSeverity.HIGH,
            timestamp = System.currentTimeMillis() - 5 * 60_000,
            icon = "crowd"
        ),
        AppNotification(
            id = "2",
            title = "Parking Zone A Almost Full",
            message = "Only 12 slots remaining in Zone A. Zone B has 60 slots available.",
            severity = NotificationSeverity.MEDIUM,
            timestamp = System.currentTimeMillis() - 20 * 60_000,
            icon = "parking"
        ),
        AppNotification(
            id = "3",
            title = "Recommended Route Changed",
            message = "Best entry is now via Gate C (East). Estimated wait: 8 mins.",
            severity = NotificationSeverity.LOW,
            timestamp = System.currentTimeMillis() - 45 * 60_000,
            icon = "route"
        ),
        AppNotification(
            id = "4",
            title = "Temple Closing in 30 Minutes",
            message = "Evening darshan will close at 9:00 PM. Please plan accordingly.",
            severity = NotificationSeverity.MEDIUM,
            timestamp = System.currentTimeMillis() - 2 * 60 * 60_000,
            icon = "bell"
        ),
        AppNotification(
            id = "5",
            title = "Emergency Alert Resolved",
            message = "The earlier incident near Gate B has been resolved. Area is now safe.",
            severity = NotificationSeverity.LOW,
            timestamp = System.currentTimeMillis() - 3 * 60 * 60_000,
            icon = "emergency",
            isRead = true
        )
    )
}
