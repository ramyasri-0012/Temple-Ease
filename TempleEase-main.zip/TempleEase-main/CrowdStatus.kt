package com.android.demo.templeease.data.model

data class CrowdStatus(

    val gateName: String = "",

    val crowdLevel: String = "",

    val latitude: Double = 0.0,

    val longitude: Double = 0.0,

    val waitingTime: String = ""
)