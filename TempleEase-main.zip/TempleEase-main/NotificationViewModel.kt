package com.android.demo.templeease.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.android.demo.templeease.data.model.AppNotification
import com.android.demo.templeease.data.repository.NotificationRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

class NotificationViewModel : ViewModel() {

    private val repository = NotificationRepository()

    val notifications: StateFlow<List<AppNotification>> =
        repository.notifications.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList()
        )

    val unreadCount: StateFlow<Int> =
        repository.notifications
            .map { list -> list.count { !it.isRead } }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    fun markAsRead(id: String) = repository.markAsRead(id)
    fun markAllRead()          = repository.markAllRead()
}
