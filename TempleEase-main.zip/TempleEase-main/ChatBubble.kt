package com.android.demo.templeease.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.TempleHindu
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.android.demo.templeease.data.model.ChatMessage
import com.android.demo.templeease.data.model.MessageSender
import com.android.demo.templeease.ui.theme.Dimens
import com.android.demo.templeease.ui.theme.Saffron
import com.android.demo.templeease.ui.theme.SaffronContainer
import com.android.demo.templeease.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Chat bubble component.
 * User messages: saffron, right-aligned.
 * Bot messages: dark surface, left-aligned with temple avatar dot.
 */
@Composable
fun ChatBubble(message: ChatMessage, modifier: Modifier = Modifier) {
    val isUser = message.sender == MessageSender.USER

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = Dimens.SpacingMd, vertical = Dimens.SpacingXxs),
        horizontalArrangement = if (isUser)
            androidx.compose.foundation.layout.Arrangement.End
        else
            androidx.compose.foundation.layout.Arrangement.Start
    ) {
        if (!isUser) {
            // Bot avatar — saffron circle with temple icon
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(SaffronContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.TempleHindu,
                    contentDescription = null,
                    tint = Saffron,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.width(Dimens.SpacingXs))
        }

        Column(horizontalAlignment = if (isUser) Alignment.End else Alignment.Start) {
            Box(
                modifier = Modifier
                    .widthIn(max = 280.dp)
                    .clip(
                        RoundedCornerShape(
                            topStart = if (isUser) Dimens.RadiusLg else Dimens.RadiusXs,
                            topEnd   = if (isUser) Dimens.RadiusXs else Dimens.RadiusLg,
                            bottomStart = Dimens.RadiusLg,
                            bottomEnd   = Dimens.RadiusLg
                        )
                    )
                    .background(
                        if (isUser) Saffron
                        else MaterialTheme.colorScheme.surfaceVariant
                    )
                    .padding(horizontal = Dimens.SpacingMd, vertical = Dimens.SpacingSm)
            ) {
                Text(
                    text = message.text,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (isUser) Color(0xFF1A0A00) else MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 20.sp
                )
            }
            Spacer(modifier = Modifier.size(2.dp))
            Text(
                text = formatChatTime(message.timestamp),
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                fontSize = 10.sp
            )
        }

        if (isUser) {
            Spacer(modifier = Modifier.width(Dimens.SpacingXs))
        }
    }
}

/** Typing indicator — three animated dots shown while bot is responding */
@Composable
fun TypingIndicator(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .padding(horizontal = Dimens.SpacingLg, vertical = Dimens.SpacingXs),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.Start,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(SaffronContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.TempleHindu, null, tint = Saffron, modifier = Modifier.size(18.dp))
        }
        Spacer(modifier = Modifier.width(Dimens.SpacingXs))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(Dimens.RadiusLg))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(horizontal = Dimens.SpacingMd, vertical = Dimens.SpacingSm)
        ) {
            Text(
                text = "● ● ●",
                color = TextSecondary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp
            )
        }
    }
}

private fun formatChatTime(ts: Long) =
    SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(ts))
