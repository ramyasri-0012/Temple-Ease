package com.android.demo.templeease.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.android.demo.templeease.data.model.ChatMessage
import com.android.demo.templeease.data.model.MessageSender
import com.android.demo.templeease.data.repository.ChatRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class ChatViewModel : ViewModel() {

    private val repository = ChatRepository()

    private val _messages  = MutableStateFlow(listOf(repository.welcomeMessage()))
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isTyping  = MutableStateFlow(false)
    val isTyping: StateFlow<Boolean> = _isTyping.asStateFlow()

    fun sendMessage(text: String) {
        if (text.isBlank()) return

        // 1. Add user message immediately
        _messages.update { it + ChatMessage(text = text, sender = MessageSender.USER) }

        // 2. Show typing indicator, then reply after realistic delay
        viewModelScope.launch {
            _isTyping.value = true
            delay(800L + (text.length * 20L).coerceAtMost(1200L)) // 800–2000ms
            _isTyping.value = false
            val response = repository.getResponse(text)
            _messages.update { it + ChatMessage(text = response, sender = MessageSender.BOT) }
        }
    }
}
