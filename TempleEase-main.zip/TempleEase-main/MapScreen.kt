package com.android.demo.templeease.ui.screens.user

import android.view.ViewGroup
import androidx.compose.runtime.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import com.android.demo.templeease.data.model.CrowdStatus
import com.android.demo.templeease.viewmodel.CrowdViewModel
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker

@Composable
fun MapScreen() {

    val viewModel: CrowdViewModel = viewModel()

    var crowdList by remember {

        mutableStateOf<List<CrowdStatus>>(emptyList())
    }

    LaunchedEffect(Unit) {

        viewModel.getCrowdStatus {

            crowdList = it
        }
    }

    AndroidView(

        factory = { context ->

            Configuration.getInstance().load(

                context,

                context.getSharedPreferences(
                    "osm",
                    0
                )
            )

            val mapView = MapView(context)

            mapView.setTileSource(
                TileSourceFactory.MAPNIK
            )

            mapView.setMultiTouchControls(true)
            mapView.isClickable = true

            mapView.isFocusable = true

            mapView.setBuiltInZoomControls(true)

            val controller = mapView.controller

            controller.setZoom(15.0)

            controller.setCenter(

                GeoPoint(
                    22.2394,
                    68.9678
                )
            )

            mapView.layoutParams = ViewGroup.LayoutParams(

                ViewGroup.LayoutParams.MATCH_PARENT,

                ViewGroup.LayoutParams.MATCH_PARENT
            )

            mapView
        },

        update = { mapView ->

            mapView.overlays.clear()

            crowdList.forEach { crowd ->

                val marker = Marker(mapView)

                marker.position = GeoPoint(

                    crowd.latitude,

                    crowd.longitude
                )

                marker.title = crowd.gateName

                marker.snippet =
                    "Crowd: ${crowd.crowdLevel}"

                mapView.overlays.add(marker)
            }

            mapView.invalidate()
        }
    )
}