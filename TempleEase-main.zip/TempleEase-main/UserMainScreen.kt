package com.android.demo.templeease.ui.screens.user

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.android.demo.templeease.ui.navigation.BottomNavItem
import com.android.demo.templeease.ui.theme.CardSurface
import com.android.demo.templeease.ui.theme.Dimens
import com.android.demo.templeease.ui.theme.NightSurface
import com.android.demo.templeease.ui.theme.Saffron
import com.android.demo.templeease.ui.theme.SaffronContainer
import com.android.demo.templeease.ui.theme.TextSecondary

/**
 * User main screen with premium styled NavigationBar.
 * - 5 tabs: Home, Map, Alerts, Parking, Profile
 * - Passes scaffoldPadding to all child screens so LazyColumns don't clip
 * - Active tab has saffron highlight with pill indicator background
 */
@Composable
fun UserMainScreen() {
    val navController = rememberNavController()

    // All 5 bottom navigation tabs
    val items = listOf(
        BottomNavItem.Home,
        BottomNavItem.Map,
        BottomNavItem.Alerts,
        BottomNavItem.Parking,
        BottomNavItem.Profile
    )

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            // ── Premium NavigationBar ─────────────────────────────────────────
            NavigationBar(
                containerColor = NightSurface,
                tonalElevation = 0.dp,
                modifier = Modifier.height(Dimens.BottomBarHeight)
            ) {
                val currentRoute =
                    navController.currentBackStackEntryAsState().value?.destination?.route

                items.forEach { item ->
                    val selected = currentRoute == item.route

                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            if (currentRoute != item.route) {
                                navController.navigate(item.route) {
                                    popUpTo(navController.graph.startDestinationId) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        },
                        icon = {
                            // Pill indicator behind active icon
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = if (selected) Modifier
                                    .size(40.dp, 32.dp)
                                    .clip(RoundedCornerShape(50))
                                    .background(SaffronContainer)
                                else Modifier
                            ) {
                                Icon(
                                    imageVector = item.icon,
                                    contentDescription = item.title,
                                    modifier = Modifier.size(Dimens.IconMd),
                                    tint = if (selected) Saffron
                                    else TextSecondary
                                )
                            }
                        },
                        label = {
                            Text(
                                text = item.title,
                                fontSize = 11.sp,
                                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                                color = if (selected) Saffron else TextSecondary
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = androidx.compose.ui.graphics.Color.Transparent
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        // ── Inner NavHost: pass scaffoldPadding to each screen ────────────────
        NavHost(
            navController = navController,
            startDestination = BottomNavItem.Home.route,
            modifier = Modifier.padding(bottom = innerPadding.calculateBottomPadding())
        ) {
            composable(BottomNavItem.Home.route) {
                HomeScreen(scaffoldPadding = innerPadding)
            }
            composable(BottomNavItem.Map.route) {
                MapScreen()
            }
            composable(BottomNavItem.Alerts.route) {
                AlertsScreen(scaffoldPadding = innerPadding)
            }
            composable(BottomNavItem.Parking.route) {
                ParkingScreen(scaffoldPadding = innerPadding)
            }
            composable(BottomNavItem.Profile.route) {
                ProfileScreen(navController)
            }
        }
    }
}