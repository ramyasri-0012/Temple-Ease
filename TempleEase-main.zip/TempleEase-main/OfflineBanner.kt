package com.android.demo.templeease.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.android.demo.templeease.ui.theme.Dimens

/** Animated amber banner shown when the device is offline.
 *  Uses AnimatedVisibility so it slides in/out smoothly. */
@Composable
fun OfflineBanner(
    isOffline: Boolean,
    message: String = "Offline · Showing cached data",
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = isOffline,
        enter   = expandVertically(),
        exit    = shrinkVertically(),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF7A4500))
                .padding(horizontal = Dimens.SpacingMd, vertical = Dimens.SpacingXs),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(Dimens.SpacingXs)
        ) {
            Icon(
                imageVector = Icons.Default.WifiOff,
                contentDescription = null,
                tint = Color(0xFFFFB946),
                modifier = Modifier.size(Dimens.IconSm)
            )
            Text(
                text = message,
                color = Color(0xFFFFE0A0),
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
