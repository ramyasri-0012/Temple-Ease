package com.android.demo.templeease.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.android.demo.templeease.data.model.RouteRecommendation
import com.android.demo.templeease.ui.theme.CardSurface
import com.android.demo.templeease.ui.theme.CrowdHigh
import com.android.demo.templeease.ui.theme.CrowdLow
import com.android.demo.templeease.ui.theme.CrowdLowContainer
import com.android.demo.templeease.ui.theme.CrowdMedium
import com.android.demo.templeease.ui.theme.CrowdMediumContainer
import com.android.demo.templeease.ui.theme.Dimens
import com.android.demo.templeease.ui.theme.ElevatedSurface
import com.android.demo.templeease.ui.theme.GoldenAccent
import com.android.demo.templeease.ui.theme.Saffron
import com.android.demo.templeease.ui.theme.SaffronContainer
import com.android.demo.templeease.ui.theme.TextSecondary

/** Crowd-aware route card showing gate name, wait time, crowd chip, and "BEST ROUTE" badge. */
@Composable
fun RouteCard(
    route: RouteRecommendation,
    modifier: Modifier = Modifier
) {
    val (accent, bgChip) = when (route.crowdLevel.uppercase()) {
        "HIGH"   -> Pair(CrowdHigh,   MaterialTheme.colorScheme.errorContainer)
        "MEDIUM" -> Pair(CrowdMedium, CrowdMediumContainer)
        else     -> Pair(CrowdLow,    CrowdLowContainer)
    }

    val cardBg = if (route.isRecommended) ElevatedSurface else CardSurface
    val borderColor = if (route.isRecommended) Saffron.copy(alpha = 0.5f)
                      else accent.copy(alpha = 0.2f)

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.5.dp, borderColor, RoundedCornerShape(Dimens.RadiusLg)),
        shape = RoundedCornerShape(Dimens.RadiusLg),
        colors = CardDefaults.cardColors(containerColor = cardBg),
        elevation = CardDefaults.cardElevation(
            defaultElevation = if (route.isRecommended) Dimens.ElevationHigh else Dimens.ElevationMid
        )
    ) {
        Column(modifier = Modifier.padding(Dimens.SpacingMd)) {

            // ── BEST ROUTE badge (only for recommended) ───────────────────────
            if (route.isRecommended) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(Dimens.SpacingXxs)
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = null,
                        tint = GoldenAccent,
                        modifier = Modifier.size(Dimens.IconSm)
                    )
                    Text(
                        text = "BEST ROUTE",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.ExtraBold),
                        color = GoldenAccent,
                        letterSpacing = 1.2.sp
                    )
                }
                Spacer(modifier = Modifier.height(Dimens.SpacingXs))
            }

            // ── Gate name + crowd chip ─────────────────────────────────────────
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = route.gateName,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                CrowdStatusChip(crowdLevel = route.crowdLevel)
            }

            Spacer(modifier = Modifier.height(Dimens.SpacingXs))

            // ── Wait time + distance row ──────────────────────────────────────
            Row(
                horizontalArrangement = Arrangement.spacedBy(Dimens.SpacingMd),
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatPill(label = "Wait", value = "${route.waitMinutes} min", color = accent)
                StatPill(label = "Distance", value = "${route.distanceMeters}m", color = TextSecondary)
                if (route.isRecommended && route.timeSavedMinutes > 0) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50.dp))
                            .background(SaffronContainer)
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "${route.timeSavedMinutes} min faster",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = Saffron
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StatPill(label: String, value: String, color: androidx.compose.ui.graphics.Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = "$label: ",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
            color = color
        )
    }
}
