package com.android.demo.templeease.ui.theme

import androidx.compose.ui.graphics.Color

// === TempleEase Brand Palette ===
// Primary: Saffron / Deep Orange
val Saffron = Color(0xFFFF6B00)
val SaffronLight = Color(0xFFFF9A3C)
val SaffronDark = Color(0xFFCC5500)
val SaffronContainer = Color(0xFF4A2000)
val OnSaffronContainer = Color(0xFFFFDDB8)

// Dark Backgrounds
val DeepNight = Color(0xFF0D0D0D)
val NightSurface = Color(0xFF141414)
val CardSurface = Color(0xFF1C1C1C)
val ElevatedSurface = Color(0xFF242424)
val HighSurface = Color(0xFF2C2C2C)

// Status Colors
val CrowdLow = Color(0xFF4CAF7D)
val CrowdLowContainer = Color(0xFF0D3321)
val CrowdMedium = Color(0xFFFFB946)
val CrowdMediumContainer = Color(0xFF3D2A00)
val CrowdHigh = Color(0xFFFF5252)
val CrowdHighContainer = Color(0xFF3D0A0A)

// Text Colors
val TextPrimary = Color(0xFFF5F0EB)
val TextSecondary = Color(0xFFB0A898)
val TextTertiary = Color(0xFF7A726A)
val TextOnSaffron = Color(0xFF1A0A00)

// Accent
val GoldenAccent = Color(0xFFFFD700)
val TealAccent = Color(0xFF00BCD4)
val SoftWhite = Color(0xFFEDE8E3)

// Divider / Outline
val OutlineSubtle = Color(0xFF2E2A26)
val OutlineMedium = Color(0xFF3D3830)