package com.android.demo.templeease.viewmodel

import android.app.Application
import androidx.datastore.preferences.core.edit
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.android.demo.templeease.utils.AppPreferencesKeys
import com.android.demo.templeease.utils.dataStore
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Persists and exposes theme + language + notification preferences via DataStore. */
class AppPreferencesViewModel(application: Application) : AndroidViewModel(application) {

    private val store = application.dataStore

    val isDarkTheme: StateFlow<Boolean> = store.data
        .map { it[AppPreferencesKeys.IS_DARK_THEME] ?: true }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), true)

    val languageCode: StateFlow<String> = store.data
        .map { it[AppPreferencesKeys.LANGUAGE_CODE] ?: "en" }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), "en")

    val notificationsEnabled: StateFlow<Boolean> = store.data
        .map { it[AppPreferencesKeys.NOTIF_ENABLED] ?: true }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), true)

    fun setDarkTheme(isDark: Boolean) = viewModelScope.launch {
        store.edit { it[AppPreferencesKeys.IS_DARK_THEME] = isDark }
    }

    fun setLanguage(code: String) = viewModelScope.launch {
        store.edit { it[AppPreferencesKeys.LANGUAGE_CODE] = code }
    }

    fun setNotificationsEnabled(enabled: Boolean) = viewModelScope.launch {
        store.edit { it[AppPreferencesKeys.NOTIF_ENABLED] = enabled }
    }
}
