package com.android.demo.templeease.ui.navigation


import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.android.demo.templeease.ui.screens.admin.AdminDashboard
import com.android.demo.templeease.ui.screens.auth.LoginScreen
import com.android.demo.templeease.ui.screens.auth.RegisterScreen
import com.android.demo.templeease.ui.screens.auth.RoleSelectionScreen
import com.android.demo.templeease.ui.screens.splash.SplashScreen
import com.android.demo.templeease.ui.screens.admin.AnalyticsScreen
import com.android.demo.templeease.ui.screens.user.UserMainScreen
import com.android.demo.templeease.ui.screens.admin.SOSMonitorScreen

@Composable
fun AppNavigation() {

    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = Routes.SPLASH
    ) {

        composable(Routes.SPLASH) {
            SplashScreen(navController)
        }

        composable(Routes.ROLE_SELECTION) {
            RoleSelectionScreen(navController)
        }

        composable(Routes.LOGIN) {
            LoginScreen(navController)
        }

        composable(Routes.REGISTER) {
            RegisterScreen(
                navController = navController,
                role = "user"
            )
        }

        composable(Routes.USER_DASHBOARD) {
            UserMainScreen()
        }

        composable(Routes.ADMIN_DASHBOARD) {
            AdminDashboard(navController)
        }
        composable(Routes.ANALYTICS) {

            AnalyticsScreen()
        }
        composable(Routes.SOS_MONITOR) {

            SOSMonitorScreen()
        }
    }
}