package com.android.demo.templeease.ui.theme

import androidx.compose.ui.unit.dp

object Dimens {
    // ── Spacing ladder ────────────────────────────────────────────────────────
    val SpacingXxs   = 4.dp
    val SpacingXs    = 8.dp
    val SpacingSm    = 12.dp
    val SpacingMd    = 16.dp
    val SpacingLg    = 20.dp
    val SpacingXl    = 24.dp
    val SpacingXxl   = 32.dp
    val SpacingXxxl  = 48.dp

    // ── Legacy aliases (keep old names alive so existing code compiles) ───────
    val ScreenPadding  = SpacingLg
    val CardPadding    = SpacingMd
    val SectionSpacing = SpacingXl
    val ItemSpacing    = SpacingSm

    // ── Corner radii ──────────────────────────────────────────────────────────
    val RadiusXs       = 8.dp
    val RadiusSm       = 12.dp
    val RadiusMd       = 16.dp
    val RadiusLg       = 20.dp
    val RadiusXl       = 24.dp
    val RadiusXxl      = 32.dp
    val RadiusCircle   = 50.dp

    // ── Legacy radius aliases ─────────────────────────────────────────────────
    val CardRadius      = RadiusXl
    val ButtonRadius    = 18.dp
    val TextFieldRadius = 18.dp

    // ── Component heights ─────────────────────────────────────────────────────
    val ButtonHeight  = 56.dp
    val TopBarHeight  = 64.dp
    val BottomBarHeight = 72.dp

    // ── Elevation ─────────────────────────────────────────────────────────────
    val ElevationNone  = 0.dp
    val ElevationLow   = 2.dp
    val ElevationMid   = 6.dp
    val ElevationHigh  = 12.dp

    // ── Icon sizes ────────────────────────────────────────────────────────────
    val IconSm  = 18.dp
    val IconMd  = 24.dp
    val IconLg  = 32.dp
    val IconXl  = 48.dp
    val IconXxl = 72.dp

    // ── Avatar ────────────────────────────────────────────────────────────────
    val AvatarSm = 40.dp
    val AvatarMd = 64.dp
    val AvatarLg = 96.dp
}