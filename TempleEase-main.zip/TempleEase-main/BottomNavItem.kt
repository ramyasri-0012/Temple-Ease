package com.android.demo.templeease.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocalParking
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.ui.graphics.vector.ImageVector

sealed class BottomNavItem(
    val route: String,
    val title: String,
    val icon: ImageVector
) {
    object Home : BottomNavItem("home", "Home", Icons.Default.Home)
    object Map : BottomNavItem("map", "Map", Icons.Default.Map)
    object Alerts : BottomNavItem("alerts", "Alerts", Icons.Default.Notifications)
    object Parking : BottomNavItem("parking", "Parking", Icons.Default.LocalParking)
    object Profile : BottomNavItem("profile", "Profile", Icons.Default.Person)
}