package com.android.demo.templeease.ui.screens.user

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.viewmodel.compose.viewModel
import com.android.demo.templeease.data.model.CrowdStatus
import com.android.demo.templeease.ui.components.CrowdCard
import com.android.demo.templeease.ui.components.LiveIndicator
import com.android.demo.templeease.ui.components.SectionHeader
import com.android.demo.templeease.ui.theme.Dimens
import com.android.demo.templeease.ui.theme.TextSecondary
import com.android.demo.templeease.viewmodel.CrowdViewModel

/**
 * Home screen displaying live crowd status per gate.
 *
 * Scrolling fixes:
 * - Accepts [scaffoldPadding] from parent Scaffold (UserMainScreen)
 * - LazyColumn uses contentPadding to consume bottom nav height
 * - No content is clipped behind the nav bar
 */
@Composable
fun HomeScreen(scaffoldPadding: PaddingValues = PaddingValues()) {
    val viewModel: CrowdViewModel = viewModel()
    var crowdList by remember { mutableStateOf<List<CrowdStatus>>(emptyList()) }

    LaunchedEffect(Unit) {
        viewModel.getCrowdStatus { crowdList = it }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = Dimens.ScreenPadding),
        // ← contentPadding ensures bottom items aren't clipped by NavBar
        contentPadding = PaddingValues(
            top = Dimens.SpacingXl,
            bottom = scaffoldPadding.calculateBottomPadding() + Dimens.SpacingMd
        ),
        verticalArrangement = Arrangement.spacedBy(Dimens.SpacingMd)
    ) {
        // ── Greeting header ───────────────────────────────────────────────────
        item {
            Text(
                text = "Good Day 🙏",
                style = MaterialTheme.typography.bodyLarge,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(Dimens.SpacingXxs))
            Text(
                text = "Temple Status",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.ExtraBold
                ),
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(Dimens.SpacingMd))
        }

        // ── Section header with LIVE badge ────────────────────────────────────
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SectionHeader(title = "Live Crowd Status")
                LiveIndicator()
            }
            Spacer(modifier = Modifier.height(Dimens.SpacingSm))
        }

        // ── Empty state ───────────────────────────────────────────────────────
        if (crowdList.isEmpty()) {
            item {
                Text(
                    text = "Fetching live data...",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        // ── Crowd cards ───────────────────────────────────────────────────────
        items(crowdList) { crowd ->
            CrowdCard(crowd = crowd)
        }
    }
}