package com.android.demo.templeease.viewmodel

import androidx.lifecycle.ViewModel
import com.android.demo.templeease.data.repository.CrowdRepository
import com.android.demo.templeease.data.model.CrowdStatus

class CrowdViewModel : ViewModel() {

    private val repository = CrowdRepository()

    fun updateCrowdStatus(

        gateName: String,
        crowdLevel: String,

        onSuccess: () -> Unit,

        onFailure: (String) -> Unit

    ) {

        repository.updateCrowdStatus(
            gateName,
            crowdLevel,
            onSuccess,
            onFailure
        )
    }
    fun getCrowdStatus(

        onDataChanged: (List<CrowdStatus>) -> Unit

    ) {

        repository.getCrowdStatus(onDataChanged)
    }
    fun sendAlert(

        title: String,
        message: String,

        onSuccess: () -> Unit,

        onFailure: (String) -> Unit

    ) {

        repository.sendAlert(
            title,
            message,
            onSuccess,
            onFailure
        )
    }
    fun sendSOS(

        location: String,
        message: String,

        onSuccess: () -> Unit,

        onFailure: (String) -> Unit

    ) {

        repository.sendSOS(

            location,
            message,

            onSuccess,
            onFailure
        )
    }
    fun updateParking(

        parkingName: String,

        availableSlots: Int,

        onSuccess: () -> Unit,

        onFailure: (String) -> Unit

    ) {

        repository.updateParking(

            parkingName,

            availableSlots,

            onSuccess,
            onFailure
        )
    }
}