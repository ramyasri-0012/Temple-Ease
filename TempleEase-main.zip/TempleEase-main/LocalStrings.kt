package com.android.demo.templeease.ui.theme

import androidx.compose.runtime.compositionLocalOf

/** All user-visible strings in the app, grouped by feature.
 *  Compose-level i18n: switch at runtime without Activity recreation. */
data class AppStrings(
    // ── General ──────────────────────────────────────────────────────────────
    val appName: String         = "TempleEase",
    val loading: String         = "Loading...",
    val ok: String              = "OK",
    val back: String            = "Back",
    val retry: String           = "Retry",

    // ── Bottom nav ────────────────────────────────────────────────────────────
    val home: String            = "Home",
    val map: String             = "Map",
    val alerts: String          = "Alerts",
    val parking: String         = "Parking",
    val profile: String         = "Profile",

    // ── Home ─────────────────────────────────────────────────────────────────
    val goodDay: String         = "Good Day 🙏",
    val templeStatus: String    = "Temple Status",
    val liveStatus: String      = "Live Crowd Status",
    val fetchingData: String    = "Fetching live data...",

    // ── Settings ─────────────────────────────────────────────────────────────
    val settings: String        = "Settings",
    val appearance: String      = "Appearance",
    val darkMode: String        = "Dark Mode",
    val darkModeDesc: String    = "Use dark background theme",
    val language: String        = "Language",
    val english: String         = "English",
    val hindi: String           = "हिंदी",
    val telugu: String          = "తెలుగు",
    val notifications: String   = "Notifications",
    val enableNotif: String     = "Enable Notifications",
    val enableNotifDesc: String = "Receive crowd & parking alerts",
    val connectivity: String    = "Connectivity",
    val connected: String       = "Connected to internet",
    val offline: String         = "No internet connection",
    val about: String           = "About",
    val version: String         = "Version 1.0",
    val hackathon: String       = "Smart India Hackathon Project",

    // ── Notifications ─────────────────────────────────────────────────────────
    val notifCenter: String     = "Notifications",
    val markAllRead: String     = "Mark all read",
    val noNotifs: String        = "All caught up!",
    val noNotifsDesc: String    = "No new notifications right now.",

    // ── Chat ──────────────────────────────────────────────────────────────────
    val chatTitle: String       = "Temple Assistant",
    val chatSubtitle: String    = "AI-powered FAQ helper",
    val chatHint: String        = "Ask me anything...",
    val chatSend: String        = "Send",
    val chatTyping: String      = "Typing...",

    // ── Routes ────────────────────────────────────────────────────────────────
    val routesTitle: String     = "Smart Routes",
    val routesSubtitle: String  = "Crowd-aware gate recommendations",
    val bestRoute: String       = "BEST ROUTE",
    val waitTime: String        = "Wait",
    val timeFaster: String      = "faster",
    val metersAway: String      = "m away",
    val loadingRoutes: String   = "Calculating best routes...",

    // ── Offline ───────────────────────────────────────────────────────────────
    val offlineBanner: String   = "Offline · Showing cached data",
)

/** Hindi translations */
val HindiStrings = AppStrings(
    appName        = "TempleEase",
    loading        = "लोड हो रहा है...",
    ok             = "ठीक है",
    back           = "वापस",
    retry          = "पुनः प्रयास",
    home           = "होम",
    map            = "नक्शा",
    alerts         = "अलर्ट",
    parking        = "पार्किंग",
    profile        = "प्रोफाइल",
    goodDay        = "प्रणाम 🙏",
    templeStatus   = "मंदिर स्थिति",
    liveStatus     = "लाइव भीड़ स्थिति",
    fetchingData   = "लाइव डेटा प्राप्त हो रहा है...",
    settings       = "सेटिंग्स",
    appearance     = "रूप",
    darkMode       = "डार्क मोड",
    darkModeDesc   = "डार्क बैकग्राउंड थीम उपयोग करें",
    language       = "भाषा",
    english        = "English",
    hindi          = "हिंदी",
    telugu         = "తెలుగు",
    notifications  = "सूचनाएं",
    enableNotif    = "सूचनाएं सक्षम करें",
    enableNotifDesc= "भीड़ और पार्किंग अलर्ट प्राप्त करें",
    connectivity   = "कनेक्टिविटी",
    connected      = "इंटरनेट से जुड़ा है",
    offline        = "इंटरनेट नहीं है",
    about          = "जानकारी",
    version        = "संस्करण 1.0",
    hackathon      = "स्मार्ट इंडिया हैकाथॉन प्रोजेक्ट",
    notifCenter    = "सूचनाएं",
    markAllRead    = "सभी पढ़ा हुआ चिह्नित करें",
    noNotifs       = "सब ठीक है!",
    noNotifsDesc   = "अभी कोई नई सूचना नहीं है।",
    chatTitle      = "मंदिर सहायक",
    chatSubtitle   = "AI-सहायता FAQ",
    chatHint       = "कुछ भी पूछें...",
    chatSend       = "भेजें",
    chatTyping     = "टाइप हो रहा है...",
    routesTitle    = "स्मार्ट रूट",
    routesSubtitle = "भीड़-जागरूक गेट सुझाव",
    bestRoute      = "सर्वश्रेष्ठ रूट",
    waitTime       = "प्रतीक्षा",
    timeFaster     = "तेज़",
    metersAway     = "मी दूर",
    loadingRoutes  = "सर्वश्रेष्ठ रूट की गणना हो रही है...",
    offlineBanner  = "ऑफलाइन · कैश डेटा दिखाया जा रहा है",
)

/** Telugu translations */
val TeluguStrings = AppStrings(
    appName        = "TempleEase",
    loading        = "లోడ్ అవుతోంది...",
    ok             = "సరే",
    back           = "వెనకకు",
    retry          = "మళ్ళీ ప్రయత్నించు",
    home           = "హోమ్",
    map            = "మ్యాప్",
    alerts         = "హెచ్చరికలు",
    parking        = "పార్కింగ్",
    profile        = "ప్రొఫైల్",
    goodDay        = "నమస్కారం 🙏",
    templeStatus   = "దేవాలయ స్థితి",
    liveStatus     = "లైవ్ జనసమ్మర్ద స్థితి",
    fetchingData   = "లైవ్ డేటా తీసుకుంటున్నాం...",
    settings       = "సెట్టింగులు",
    appearance     = "రూపం",
    darkMode       = "డార్క్ మోడ్",
    darkModeDesc   = "డార్క్ నేపథ్య థీమ్ ఉపయోగించండి",
    language       = "భాష",
    english        = "English",
    hindi          = "हिंदी",
    telugu         = "తెలుగు",
    notifications  = "నోటిఫికేషన్లు",
    enableNotif    = "నోటిఫికేషన్లు ఆన్ చేయి",
    enableNotifDesc= "జనసమ్మర్ద & పార్కింగ్ హెచ్చరికలు పొందండి",
    connectivity   = "కనెక్టివిటీ",
    connected      = "ఇంటర్నెట్‌కు కనెక్ట్ అయింది",
    offline        = "ఇంటర్నెట్ కనెక్షన్ లేదు",
    about          = "గురించి",
    version        = "వెర్షన్ 1.0",
    hackathon      = "స్మార్ట్ ఇండియా హ్యాకథాన్ ప్రాజెక్ట్",
    notifCenter    = "నోటిఫికేషన్లు",
    markAllRead    = "అన్నీ చదివినట్టు గుర్తించు",
    noNotifs       = "అన్నీ సరేనా!",
    noNotifsDesc   = "ఇప్పుడు కొత్త నోటిఫికేషన్లు లేవు.",
    chatTitle      = "దేవాలయ సహాయకుడు",
    chatSubtitle   = "AI-సహాయిత FAQ",
    chatHint       = "ఏదైనా అడగండి...",
    chatSend       = "పంపు",
    chatTyping     = "టైప్ అవుతోంది...",
    routesTitle    = "స్మార్ట్ రూట్లు",
    routesSubtitle = "జనసమ్మర్ద-అవగాహన గేట్ సూచనలు",
    bestRoute      = "అత్యుత్తమ రూట్",
    waitTime       = "వేచి",
    timeFaster     = "వేగంగా",
    metersAway     = "మీ దూరం",
    loadingRoutes  = "అత్యుత్తమ రూట్లు లెక్కిస్తున్నాం...",
    offlineBanner  = "ఆఫ్‌లైన్ · కాష్ చేసిన డేటా చూపిస్తున్నాం",
)

/** Returns the right AppStrings for the given language code */
fun stringsFor(code: String): AppStrings = when (code) {
    "hi" -> HindiStrings
    "te" -> TeluguStrings
    else -> AppStrings()
}

/** CompositionLocal that provides localized strings throughout the Compose tree */
val LocalAppStrings = compositionLocalOf { AppStrings() }
