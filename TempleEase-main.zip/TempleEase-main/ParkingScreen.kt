package com.android.demo.templeease.ui.screens.user

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.LocalParking
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.android.demo.templeease.data.model.ParkingStatus
import com.android.demo.templeease.ui.components.SectionHeader
import com.android.demo.templeease.ui.theme.CardSurface
import com.android.demo.templeease.ui.theme.CrowdHigh
import com.android.demo.templeease.ui.theme.CrowdLow
import com.android.demo.templeease.ui.theme.CrowdLowContainer
import com.android.demo.templeease.ui.theme.Dimens
import com.android.demo.templeease.ui.theme.Saffron
import com.android.demo.templeease.ui.theme.SaffronContainer
import com.android.demo.templeease.ui.theme.TextSecondary
import com.google.firebase.firestore.FirebaseFirestore

/**
 * Parking availability screen.
 *
 * Scrolling fix:
 * - Accepts [scaffoldPadding] from Scaffold
 * - LazyColumn contentPadding prevents clipping behind NavBar
 */
@Composable
fun ParkingScreen(scaffoldPadding: PaddingValues = PaddingValues()) {
    var parkingList by remember { mutableStateOf<List<ParkingStatus>>(emptyList()) }

    LaunchedEffect(Unit) {
        FirebaseFirestore.getInstance()
            .collection("parking")
            .addSnapshotListener { value, _ ->
                val tempList = mutableListOf<ParkingStatus>()
                value?.documents?.forEach {
                    val parking = it.toObject(ParkingStatus::class.java)
                    if (parking != null) tempList.add(parking)
                }
                parkingList = tempList
            }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = Dimens.ScreenPadding),
        contentPadding = PaddingValues(
            top = Dimens.SpacingXl,
            bottom = scaffoldPadding.calculateBottomPadding() + Dimens.SpacingMd
        ),
        verticalArrangement = Arrangement.spacedBy(Dimens.SpacingMd)
    ) {
        // ── Header ────────────────────────────────────────────────────────────
        item {
            Text(
                text = "Parking",
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold),
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(Dimens.SpacingSm))
            SectionHeader(title = "Available Zones")
            Spacer(modifier = Modifier.height(Dimens.SpacingSm))
        }

        // ── Empty state ───────────────────────────────────────────────────────
        if (parkingList.isEmpty()) {
            item {
                Text(
                    text = "Loading parking data...",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        // ── Parking cards ─────────────────────────────────────────────────────
        items(parkingList) { parking ->
            val isAvailable = parking.availableSlots > 0
            val accentColor = if (isAvailable) CrowdLow else CrowdHigh
            val iconBg = if (isAvailable) CrowdLowContainer else MaterialTheme.colorScheme.errorContainer

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        accentColor.copy(alpha = 0.25f),
                        RoundedCornerShape(Dimens.RadiusLg)
                    ),
                shape = RoundedCornerShape(Dimens.RadiusLg),
                colors = CardDefaults.cardColors(containerColor = CardSurface),
                elevation = CardDefaults.cardElevation(defaultElevation = Dimens.ElevationMid)
            ) {
                Row(
                    modifier = Modifier.padding(Dimens.SpacingMd),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Icon box
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(Dimens.RadiusMd))
                            .background(iconBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocalParking,
                            contentDescription = null,
                            tint = accentColor,
                            modifier = Modifier.size(Dimens.IconMd)
                        )
                    }

                    Spacer(modifier = Modifier.width(Dimens.SpacingMd))

                    // Info
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = parking.parkingName,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(Dimens.SpacingXxs))
                        Text(
                            text = if (isAvailable) "Available" else "Full",
                            style = MaterialTheme.typography.bodySmall,
                            color = accentColor
                        )
                    }

                    // Slot badge
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(if (isAvailable) SaffronContainer else MaterialTheme.colorScheme.errorContainer)
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${parking.availableSlots} slots",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = if (isAvailable) Saffron else CrowdHigh
                        )
                    }
                }
            }
        }
    }
}