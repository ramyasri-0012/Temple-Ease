package com.android.demo.templeease.data.repository

import com.android.demo.templeease.data.model.ChatMessage
import com.android.demo.templeease.data.model.MessageSender

/** Rule-based FAQ chatbot engine.
 *  Keyword matching covers the most common temple visitor queries.
 *  Swap getResponse() with a real LLM/Gemini call when ready. */
class ChatRepository {

    fun getResponse(userMessage: String): String {
        val msg = userMessage.lowercase().trim()
        return when {
            msg.contains("hi") || msg.contains("hello") || msg.contains("namaste") || msg.contains("hai") ->
                "Namaste! 🙏 Welcome to TempleEase. I can help with crowd status, parking, darshan timings, routes, and emergencies. What would you like to know?"

            msg.contains("gate") && (msg.contains("crowd") || msg.contains("busy") || msg.contains("less")) ->
                "Based on live data:\n🟢 Gate B (East) — LOW crowd, ~8 min wait\n🟡 Gate A (Main) — MEDIUM crowd, ~25 min wait\n🔴 Gate C (West) — HIGH crowd, ~45 min wait\n\nI recommend using Gate B right now!"

            msg.contains("crowd") || msg.contains("wait") || msg.contains("busy") ->
                "Current crowd levels:\n• Gate A (Main): MEDIUM — ~25 min wait\n• Gate B (East): LOW — ~8 min wait ✅ Best\n• Gate C (West): HIGH — ~45 min wait\n\nCheck the Home screen for live updates."

            msg.contains("park") ->
                "🅿️ Parking availability right now:\n• Zone A (North): Full 🔴\n• Zone B (East): 60 slots available 🟢\n• Zone C (South): 30 slots available 🟡\n\nZone B is your best option. It's a 3-minute walk to Gate B."

            msg.contains("time") || msg.contains("timing") || msg.contains("open") || msg.contains("hours") ->
                "⏰ Temple timings:\n• Morning: 5:00 AM – 12:00 PM\n• Afternoon: Break 12:00 – 4:00 PM\n• Evening: 4:00 PM – 9:00 PM\n\nAbhishekam is at 6:00 AM and 6:00 PM daily."

            msg.contains("darshan") ->
                "🙏 Darshan information:\n• General Darshan: ~45 min wait (current)\n• Seegra Darshan: ₹300 | ~15 min wait\n• VIP Darshan: ₹500 | ~5 min wait\n\nTickets available at the counter near Gate A."

            msg.contains("sos") || msg.contains("emergency") || msg.contains("help") || msg.contains("danger") ->
                "🚨 EMERGENCY ASSISTANCE\n\nFor immediate help:\n1. Go to Profile → Send Emergency SOS\n2. Temple Security: +91-XXXX-XXXX\n3. Move to the nearest gate exit\n4. Emergency assembly point: Near Gate B parking\n\nStay calm. Help is on the way!"

            msg.contains("route") || msg.contains("direction") || msg.contains("way") || msg.contains("path") ->
                "🗺️ Best route right now:\n\nRecommended: Gate B (East Entrance)\n• ~8 min wait time\n• 15 mins faster than Gate A\n• Parking Zone B is adjacent\n\nOpen the Routes tab for detailed guidance."

            msg.contains("prasad") || msg.contains("prashad") ->
                "🍚 Prasad & Food:\n• Free Prasadam: Near Gate A counter\n• Annadanam (free meal): 12 PM – 2 PM\n• Paid Prasadam: ₹50–₹500 at main counter\n• Café & snacks near Parking Zone B"

            msg.contains("toilet") || msg.contains("washroom") || msg.contains("restroom") ->
                "🚻 Restrooms are available at:\n• All 3 gate entrances\n• Near the main darshan hall\n• Parking Zone A and Zone B\n\nThey are cleaned every 30 minutes."

            msg.contains("close") || msg.contains("clos") ->
                "The temple closes at 12:00 PM (afternoon) and 9:00 PM (evening). Last entry is 30 minutes before closing time."

            msg.contains("dress") || msg.contains("code") || msg.contains("wear") ->
                "👗 Dress Code:\n• Traditional attire preferred\n• Dhoti/saree is recommended\n• No shorts, sleeveless tops, or revealing clothes\n• Footwear must be removed before entry"

            msg.contains("thank") ->
                "You're welcome! 🙏 May your visit be blessed. Is there anything else I can help you with?"

            else ->
                "I can help you with:\n• 🚶 Gate crowd & wait times\n• 🅿️ Parking availability\n• ⏰ Temple timings & darshan\n• 🗺️ Best routes\n• 🚨 Emergencies\n• 🍚 Prasad & amenities\n\nPlease ask about any of these!"
        }
    }

    /** Generates the initial welcome message from the bot */
    fun welcomeMessage() = ChatMessage(
        text = "Namaste! 🙏 I'm your TempleEase assistant. Ask me about crowd levels, parking, darshan timings, routes, or emergencies.",
        sender = MessageSender.BOT
    )
}
