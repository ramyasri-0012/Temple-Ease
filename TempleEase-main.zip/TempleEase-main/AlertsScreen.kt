package com.android.demo.templeease.ui.screens.user

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.android.demo.templeease.ui.components.LiveIndicator
import com.android.demo.templeease.ui.components.SectionHeader
import com.android.demo.templeease.ui.theme.CardSurface
import com.android.demo.templeease.ui.theme.CrowdHigh
import com.android.demo.templeease.ui.theme.Dimens
import com.android.demo.templeease.ui.theme.TextSecondary
import com.google.firebase.firestore.FirebaseFirestore

data class AlertItem(
    val title: String = "",
    val message: String = ""
)

/**
 * Live alerts screen.
 *
 * Scrolling fix:
 * - Accepts [scaffoldPadding] from Scaffold
 * - LazyColumn contentPadding consumes nav bar height so no clipping occurs
 */
@Composable
fun AlertsScreen(scaffoldPadding: PaddingValues = PaddingValues()) {
    var alertList by remember { mutableStateOf<List<AlertItem>>(emptyList()) }

    LaunchedEffect(Unit) {
        FirebaseFirestore.getInstance()
            .collection("alerts")
            .addSnapshotListener { value, _ ->
                val tempList = mutableListOf<AlertItem>()
                value?.documents?.forEach {
                    val alert = it.toObject(AlertItem::class.java)
                    if (alert != null) tempList.add(alert)
                }
                alertList = tempList
            }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = Dimens.ScreenPadding),
        contentPadding = PaddingValues(
            top = Dimens.SpacingXl,
            bottom = scaffoldPadding.calculateBottomPadding() + Dimens.SpacingMd
        ),
        verticalArrangement = Arrangement.spacedBy(Dimens.SpacingMd)
    ) {
        // ── Header ────────────────────────────────────────────────────────────
        item {
            Text(
                text = "Alerts",
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold),
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(Dimens.SpacingSm))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SectionHeader(title = "Live Alerts")
                LiveIndicator()
            }
            Spacer(modifier = Modifier.height(Dimens.SpacingSm))
        }

        // ── Empty state ───────────────────────────────────────────────────────
        if (alertList.isEmpty()) {
            item {
                Text(
                    text = "No active alerts right now.",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        // ── Alert cards with red left border ──────────────────────────────────
        items(alertList) { alert ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        width = 1.dp,
                        color = CrowdHigh.copy(alpha = 0.3f),
                        shape = RoundedCornerShape(Dimens.RadiusLg)
                    ),
                shape = RoundedCornerShape(Dimens.RadiusLg),
                colors = CardDefaults.cardColors(containerColor = CardSurface),
                elevation = CardDefaults.cardElevation(defaultElevation = Dimens.ElevationMid)
            ) {
                Row(
                    modifier = Modifier.padding(Dimens.SpacingMd),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = CrowdHigh,
                        modifier = Modifier.size(Dimens.IconMd)
                    )
                    Spacer(modifier = Modifier.width(Dimens.SpacingMd))
                    Column {
                        Text(
                            text = alert.title,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (alert.message.isNotBlank()) {
                            Spacer(modifier = Modifier.height(Dimens.SpacingXxs))
                            Text(
                                text = alert.message,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}