package com.android.demo.templeease.data.model

/** A crowd-aware gate route recommendation shown on the Routes screen */
data class RouteRecommendation(
    val gateName: String,
    val crowdLevel: String,       // "LOW" | "MEDIUM" | "HIGH"
    val waitMinutes: Int,
    val distanceMeters: Int,
    val isRecommended: Boolean = false,
    val timeSavedMinutes: Int = 0 // vs. the busiest alternative
)
