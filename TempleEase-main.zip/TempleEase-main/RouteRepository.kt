package com.android.demo.templeease.data.repository

import com.android.demo.templeease.data.model.CrowdStatus
import com.android.demo.templeease.data.model.RouteRecommendation
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.map

/** Fetches crowd data from Firestore and ranks gates as route recommendations.
 *  Falls back to demo data when Firestore is unavailable. */
class RouteRepository {

    private val db = FirebaseFirestore.getInstance()

    /** Live Flow of ranked RouteRecommendations, best gate first. */
    fun getRouteRecommendations(): Flow<List<RouteRecommendation>> =
        crowdFlow().map { list -> rankGates(list) }

    private fun crowdFlow(): Flow<List<CrowdStatus>> = callbackFlow {
        val listener = db.collection("crowd_status")
            .addSnapshotListener { snapshot, _ ->
                val items = snapshot?.documents?.mapNotNull {
                    it.toObject(CrowdStatus::class.java)
                } ?: emptyList()
                // Fall back to demo data if Firestore returns nothing
                trySend(items.ifEmpty { demoGates() })
            }
        awaitClose { listener.remove() }
    }

    private fun rankGates(crowds: List<CrowdStatus>): List<RouteRecommendation> {
        // Assign wait minutes and distance based on crowd level
        val recs = crowds.mapIndexed { index, cs ->
            val wait = when (cs.crowdLevel.uppercase()) {
                "HIGH"   -> 40 + (index * 5)
                "MEDIUM" -> 20 + (index * 3)
                else     -> 8 + (index * 2)
            }
            val dist = 200 + (index * 150)
            RouteRecommendation(
                gateName        = cs.gateName,
                crowdLevel      = cs.crowdLevel,
                waitMinutes     = wait,
                distanceMeters  = dist
            )
        }
        // Sort: LOW first, then MEDIUM, then HIGH; break ties by wait time
        val order = mapOf("LOW" to 0, "MEDIUM" to 1, "HIGH" to 2)
        val sorted = recs.sortedWith(
            compareBy({ order[it.crowdLevel.uppercase()] ?: 3 }, { it.waitMinutes })
        )
        // Mark the best gate and compute time saved vs worst
        val maxWait = sorted.maxOfOrNull { it.waitMinutes } ?: 0
        return sorted.mapIndexed { i, r ->
            r.copy(
                isRecommended    = i == 0,
                timeSavedMinutes = if (i == 0) maxWait - r.waitMinutes else 0
            )
        }
    }

    /** Demo gates when Firestore is offline or empty */
    private fun demoGates() = listOf(
        CrowdStatus(gateName = "Gate A (Main)",  crowdLevel = "MEDIUM", waitingTime = "25 mins", latitude = 22.240, longitude = 68.968),
        CrowdStatus(gateName = "Gate B (East)",  crowdLevel = "LOW",    waitingTime = "8 mins",  latitude = 22.241, longitude = 68.970),
        CrowdStatus(gateName = "Gate C (West)",  crowdLevel = "HIGH",   waitingTime = "45 mins", latitude = 22.238, longitude = 68.966)
    )
}
