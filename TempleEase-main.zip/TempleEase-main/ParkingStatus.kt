package com.android.demo.templeease.data.model

data class ParkingStatus(

    val parkingName: String = "",

    val availableSlots: Int = 0
)