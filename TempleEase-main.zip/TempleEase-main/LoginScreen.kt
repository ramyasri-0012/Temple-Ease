package com.android.demo.templeease.ui.screens.auth

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.TempleHindu
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.android.demo.templeease.ui.components.TempleButton
import com.android.demo.templeease.ui.components.TempleTextField
import com.android.demo.templeease.ui.navigation.Routes
import com.android.demo.templeease.ui.theme.DeepNight
import com.android.demo.templeease.ui.theme.Dimens
import com.android.demo.templeease.ui.theme.Saffron
import com.android.demo.templeease.ui.theme.SaffronContainer
import com.android.demo.templeease.ui.theme.TextSecondary
import com.android.demo.templeease.viewmodel.AuthViewModel

/**
 * Modern login screen with:
 * - Centered branding (logo + title)
 * - Themed TempleTextField components with icons
 * - Password show/hide toggle
 * - imePadding + verticalScroll so keyboard never obscures fields
 * - Loading state on the login button
 * - Navigates to admin or user dashboard based on Firebase role
 */
@Composable
fun LoginScreen(navController: NavController) {
    val viewModel: AuthViewModel = viewModel()
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepNight)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)   // ← Fixes keyboard-hiding-fields bug
                .imePadding()                  // ← Pushes content above keyboard
                .padding(horizontal = Dimens.ScreenPadding)
                .padding(vertical = Dimens.SpacingXxxl),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // ── Branding ──────────────────────────────────────────────────────
            Box(
                modifier = Modifier
                    .size(Dimens.AvatarMd)
                    .clip(CircleShape)
                    .background(SaffronContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.TempleHindu,
                    contentDescription = null,
                    tint = Saffron,
                    modifier = Modifier.size(Dimens.IconXl)
                )
            }

            Spacer(modifier = Modifier.height(Dimens.SpacingXl))

            Text(
                text = "Sign In",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.ExtraBold
                ),
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(Dimens.SpacingXs))
            Text(
                text = "Sign in to manage your temple experience",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(Dimens.SpacingXxl))

            // ── Email field ───────────────────────────────────────────────────
            TempleTextField(
                value = email,
                onValueChange = { email = it },
                label = "Email address",
                leadingIcon = Icons.Default.Email,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Email,
                    imeAction = ImeAction.Next
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(Dimens.SpacingMd))

            // ── Password field ────────────────────────────────────────────────
            TempleTextField(
                value = password,
                onValueChange = { password = it },
                label = "Password",
                leadingIcon = Icons.Default.Lock,
                visualTransformation = if (passwordVisible)
                    VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(
                            imageVector = if (passwordVisible)
                                Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = if (passwordVisible) "Hide" else "Show",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Done
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(Dimens.SpacingXl))

            // ── Login button ──────────────────────────────────────────────────
            TempleButton(
                text = "Sign In",
                isLoading = isLoading,
                onClick = {
                    isLoading = true
                    viewModel.loginUser(
                        email, password,
                        onSuccess = { role ->
                            isLoading = false
                            Toast.makeText(context, "Login Successful", Toast.LENGTH_SHORT).show()
                            if (role == "admin") {
                                navController.navigate(Routes.ADMIN_DASHBOARD)
                            } else {
                                navController.navigate(Routes.USER_DASHBOARD)
                            }
                        },
                        onFailure = {
                            isLoading = false
                            Toast.makeText(context, it, Toast.LENGTH_LONG).show()
                        }
                    )
                }
            )

            Spacer(modifier = Modifier.height(Dimens.SpacingMd))

            // ── Register link ─────────────────────────────────────────────────
            TextButton(onClick = { navController.navigate(Routes.REGISTER) }) {
                Text(
                    text = "Don't have an account?  ",
                    color = TextSecondary,
                    fontSize = 14.sp
                )
                Text(
                    text = "Create one",
                    color = Saffron,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp
                )
            }
        }
    }
}