package com.android.demo.templeease.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.android.demo.templeease.data.model.AppNotification
import com.android.demo.templeease.data.model.NotificationSeverity
import com.android.demo.templeease.ui.theme.CardSurface
import com.android.demo.templeease.ui.theme.CrowdHigh
import com.android.demo.templeease.ui.theme.CrowdHighContainer
import com.android.demo.templeease.ui.theme.CrowdLow
import com.android.demo.templeease.ui.theme.CrowdLowContainer
import com.android.demo.templeease.ui.theme.CrowdMedium
import com.android.demo.templeease.ui.theme.CrowdMediumContainer
import com.android.demo.templeease.ui.theme.Dimens
import com.android.demo.templeease.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Color-coded notification card with severity left-strip, icon, title, message, timestamp. */
@Composable
fun NotificationCard(
    notification: AppNotification,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val (accent, bg, icon) = severityStyle(notification.severity, notification.icon)

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .border(1.dp, accent.copy(alpha = 0.25f), RoundedCornerShape(Dimens.RadiusLg)),
        shape = RoundedCornerShape(Dimens.RadiusLg),
        colors = CardDefaults.cardColors(
            containerColor = if (notification.isRead) CardSurface else bg.copy(alpha = 0.35f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = Dimens.ElevationMid)
    ) {
        Row(
            modifier = Modifier.padding(Dimens.SpacingMd),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Colored icon circle
            Box(
                modifier = Modifier
                    .size(Dimens.AvatarSm)
                    .clip(CircleShape)
                    .background(bg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(Dimens.IconMd)
                )
            }

            Spacer(modifier = Modifier.width(Dimens.SpacingMd))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = notification.title,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = if (notification.isRead) TextSecondary
                                else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    // Unread dot
                    if (!notification.isRead) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(accent)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(Dimens.SpacingXxs))
                Text(
                    text = notification.message,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(Dimens.SpacingXxs))
                Text(
                    text = formatTime(notification.timestamp),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                    fontSize = 10.sp
                )
            }
        }
    }
}

private data class SeverityStyle(
    val accent: Color,
    val bg: Color,
    val icon: ImageVector
)

private fun severityStyle(severity: NotificationSeverity, iconTag: String): SeverityStyle {
    val icon = when (iconTag) {
        "crowd"     -> Icons.Default.People
        "parking"   -> Icons.Default.DirectionsCar
        "emergency" -> Icons.Default.Warning
        "route"     -> Icons.Default.Campaign
        else        -> Icons.Default.Notifications
    }
    return when (severity) {
        NotificationSeverity.HIGH   -> SeverityStyle(CrowdHigh,   CrowdHighContainer,   icon)
        NotificationSeverity.MEDIUM -> SeverityStyle(CrowdMedium, CrowdMediumContainer, icon)
        NotificationSeverity.LOW    -> SeverityStyle(CrowdLow,    CrowdLowContainer,    icon)
    }
}

private fun formatTime(ts: Long): String {
    val diff = System.currentTimeMillis() - ts
    return when {
        diff < 60_000      -> "Just now"
        diff < 3_600_000   -> "${diff / 60_000} min ago"
        diff < 86_400_000  -> "${diff / 3_600_000} hr ago"
        else               -> SimpleDateFormat("MMM d", Locale.getDefault()).format(Date(ts))
    }
}
