package com.android.demo.templeease.data.model

import java.util.UUID

/** Who sent a chat message */
enum class MessageSender { USER, BOT }

/** A single message in the AI chatbot conversation */
data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val sender: MessageSender,
    val timestamp: Long = System.currentTimeMillis()
)
