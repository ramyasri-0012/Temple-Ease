package com.android.demo.templeease

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.android.demo.templeease.ui.navigation.AppNavigation
import com.android.demo.templeease.ui.theme.TempleEaseTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {

            TempleEaseTheme {

                AppNavigation()
            }
        }
    }
}